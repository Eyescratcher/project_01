function Assignment(title, description, subDateTime, oralMark, totalMark){
    this.title = title;
    this.description = description;
    this.subDateTime = subDateTime;
    this.oralMark = oralMark;
    this.totalMark = totalMark;
}

function assignmentToString(assignment){
    return (`Title:             ${assignment.title} 
             Description:       ${assignment.description} 
             Submission Date:   ${assignment.subDateTime} 
             Oral Mark:         ${assignment.oralMark} 
             Total Mark:        ${assignment.oralMark}`)
}

let assignments=[];
    let assignmentTitle=document.getElementById("title");
    let assignmentDescription=document.getElementById("description");
    let assignmentSubDateTime=document.getElementById("subDateTime");
    let assignmentOralMark=document.getElementById("oralMark");
    let assignmentTotalMark=document.getElementById("totalMark")
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divAssignments=document.getElementById("assignments");

    function submit(event){
        event.preventDefault();
        let myAssignment=new Assignment(assignmentTitle.value, assignmentDescription.value, assignmentSubDateTime.value, assignmentOralMark.value, assignmentTotalMark.value);
        assignments.push(myAssignment);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.assignmentIndex=assignments.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myAssignment,btnEdit);
        btnReset.click();
        console.log(assignments);
    }

    function reset(event){
        btnSubmit.textContent="Add";
    }

    function edit(event){
        assignmentTitle.value=assignments[this.assignmentIndex].title;
        assignmentDescription.value=assignments[this.assignmentIndex].description;
        assignmentSubDateTime.value=assignments[this.assignmentIndex].subDateTime;
        assignmentOralMark.value=assignments[this.assignmentIndex].oralMark;
        assignmentTotalMark.value=assignments[this.assignmentIndex].toralMark;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.assignmentIndex=this.assignmentIndex;
    }

    function update(event){
        event.preventDefault();
        assignments[this.assignmentIndex]=new Assignment(assignmentTitle.value, assignmentDescription.value, assignmentSubDateTime.value, assignmentOralMark.value, assignmentTotalMark.value);
        divAssignments.innerHTML="";
        for(let i=0; i< assignments.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.assignmentIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(assignments[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(assignment,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=assignmentToString(assignment);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;'
        paragraph.append(spanSpace,editButton);
        divAssignments.append(paragraph);
    }
const trainersArrayName = 'trainers';
const trainerCourseArrayName = 'trainerCourse';

function getArrayFromLSByName(arrayName){
    let arrayLS = localStorage.getItem(arrayName);
    if(!arrayLS){
        setArrayFromLSByName([]);
        return [];
    }
    return JSON.parse(arrayLS);
}

function setArrayFromLSByName(arrayName,arrayLS){
    localStorage.setItem(arrayName, JSON.stringify(arrayLS));
}

function addTrainer(){
    const firstname = document.getElementById('firstName').value;
    const lastname = document.getElementById('lastName').value;
    const subject = document.querySelector('#subject').value;

    let trainersArr = getArrayFromLSByName(trainersArrayName);
    let trainer = {
        firstname,
        lastname,
        subject
    };

    trainersArr.push(trainer);

    setArrayFromLSByName(trainersArrayName, trainersArr);

    addTrainerCourse(lastname, subject);
    return;
}

function updateTrainersUiList(){
    let trainersArr = getArrayFromLSByName(trainersArrayName);
    let trainersList = document.querySelector('#trainers');
    
    for (i=0; i < trainersArr.length; i++){
        var option = document.createElement("option");
        option.text = `${trainersArr[i].firstname} ${trainersArr[i].lastname}`;
        trainersList.add(option);
    }

    loadCourse({selectedIndex: 0});
}

function loadCourse(obj){
    let trainersArr = getArrayFromLSByName(trainersArrayName);
    const courseName = trainersArr[obj.selectedIndex].subject;
    let coursesEl = document.getElementById('courses');
    coursesEl.innerHTML = courseName;
}

function clearLS(){
    setArrayFromLSByName(trainersArrayName, []);
    window.location.reload();
}


function hello(){

    
    alert("den exw kanei tpt edw, ta add kai edit den paizoun. Phgaine allou!!!")
}
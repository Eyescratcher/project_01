function Trainer(firstName, lastName, subject){
    this.firstName = firstName;
    this.lastName = lastName;
    this.subject = subject;
}

function trainerToString(trainer){
    return (`First Name: ${trainer.firstName} 
             Last Name:  ${trainer.lastName} 
             Subject:    ${trainer.subject}`)
}

let trainers=[];
    let trainerFirstName=document.getElementById("firstName");
    let trainerLastName=document.getElementById("lastName");
    let trainersubject=document.getElementById("subject");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divTrainers=document.getElementById("trainers");

    function submit(event){
        event.preventDefault();
        let mytrainer=new Trainer(trainerFirstName.value, trainerLastName.value, trainersubject.value);
        trainers.push(mytrainer);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.trainerIndex=trainers.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(mytrainer,btnEdit);
        btnReset.click();
        console.log(trainers);
    }

    function reset(event){
        btnSubmit.textContent="Add";
    }

    function edit(event){
        trainerFirstName.value=trainers[this.trainerIndex].firstName;
        trainerLastName.value=trainers[this.trainerIndex].lastName;
        trainersubject.value=trainers[this.trainerIndex].subject;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.trainerIndex=this.trainerIndex;
    }

    function update(event){
        event.preventDefault();
        trainers[this.trainerIndex]=new Trainer(trainerFirstName.value, trainerLastName.value, trainersubject.value);
        divTrainers.innerHTML="";
        for(let i=0; i< trainers.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.trainerIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(trainers[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(trainer,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=trainerToString(trainer);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;'
        paragraph.append(spanSpace,editButton);
        divTrainers.append(paragraph);
    }


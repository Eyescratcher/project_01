function AsCourse(assignment, course){
    this.assignment = assignment;
    this.course = course;
}

function asignCourseToString(ascourse){
    return (`Assignment: ${ascourse.assignment} 
             Course:     ${ascourse.course}`)
}

let asCourse=[];
    let asName=document.getElementById("assignment");
    let courseName=document.getElementById("course");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divAsCourses=document.getElementById("assigncourses");

    function submit(event){
        event.preventDefault();
        let myAsCourses=new AsCourse(asName.value, courseName.value);
        asCourse.push(myAsCourses);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.asCourseIndex=asCourse.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myAsCourses,btnEdit);
        btnReset.click();
        console.log(asCourse);
    }

    function reset(event){
        btnSubmit.textContent="Add";
    }

    function edit(event){
        asName.value=asCourse[this.asCourseIndex].assignment;
        courseName.value=asCourse[this.asCourseIndex].course;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.asCourseIndex=this.asCourseIndex;
    }

    function update(event){
        event.preventDefault();
        asCourse[this.asCourseIndex]=new AsCourse(asName.value, courseName.value);
        divTrainers.innerHTML="";
        for(let i=0; i< asCourse.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.asCourseIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(asCourse[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(ascourse,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=asignCourseToString(ascourse);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;'
        paragraph.append(spanSpace,editButton);
        divAsCourses.append(paragraph);
    }


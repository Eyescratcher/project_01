const studentsArrayName = 'students';

function getArrayFromLSByName(arrayName){
    let arrayLS = localStorage.getItem(arrayName);
    if(!arrayLS){
        setArrayFromLSByName([]);
        return [];
    }
    return JSON.parse(arrayLS);
}

function setArrayFromLSByName(arrayName,arrayLS){
    localStorage.setItem(arrayName, JSON.stringify(arrayLS));
}

function addStudent(){
    const firstname = document.getElementById('firstName').value;
    const lastname = document.getElementById('lastName').value;
    const subject = document.getElementById('birthday').value;
    const tuition = document.getElementById('tuition').value;    

    let studentsArr = getArrayFromLSByName(studentsArrayName);
    let student = {
        firstname,
        lastname,
        subject,
        tuition
    };

    studentsArr.push(student);

    setArrayFromLSByName(studentsArrayName, studentsArr);

    addStudentCourse(lastname, subject);
    return;
}

function updateStudentsUiList(){
    let studentsArr = getArrayFromLSByName(studentsArrayName);
    let studentsList = document.querySelector('#students');
    
    for (i=0; i < studentsArr.length; i++){
        var option = document.createElement("option");
        option.text = `${studentsArr[i].firstname} ${studentsArr[i].lastname}`;
        studentsList.add(option);
    }

    loadCourse({selectedIndex: 0});
}

function loadCourse(obj){
    let studentArr = getArrayFromLSByName(studentsArrayName);
    const courseName = studentsArr[obj.selectedIndex].subject;
    let coursesEl = document.getElementById('courses');
    coursesEl.innerHTML = courseName;
}

function clearLS(){
    setArrayFromLSByName(studentsArrayName, []);
    window.location.reload();
}

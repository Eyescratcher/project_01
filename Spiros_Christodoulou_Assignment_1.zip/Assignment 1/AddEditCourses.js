function Course(title, stream, type, startDate, endDate){
    this.title = title;
    this.stream = stream;
    this.type = type;
    this.startDate = startDate;
    this.endDate = endDate;
}

function courseToString(course){
    return (`Title:      ${course.title} 
             Stream:     ${course.stream}
             Type:       ${course.type} 
             Start Date: ${course.startDate} 
             End Date:   ${course.endDate}`)

            //  return (`Title:      ${course.title} 
            //  Stream:     ${course.stream} 
            //  Type:       ${course.type} 
            //  Start Date: ${course.startDate} 
            //  End Date:   ${course.endDate}`)
}

let courses=[];
    let courseTitle=document.getElementById("title");
    let courseStream=document.getElementById("stream");
    let courseType=document.getElementById("type");
    let courseStartDate=document.getElementById("startDate");
    let courseEndDate=document.getElementById("endDate");
    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divCourses=document.getElementById("courses");

    function submit(event){
        event.preventDefault();
        let myCourse=new Course(courseTitle.value, courseStream.value, courseType.value, courseStartDate.value, courseEndDate.value);
        courses.push(myCourse);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.courseIndex=courses.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(myCourse,btnEdit);
        btnReset.click();
        console.log(courses);
    }

    function reset(event){
        btnSubmit.textContent="Add";
    }

    function edit(event){
        courseTitle.value=courses[this.courseIndex].title;
        courseStream.value=courses[this.courseIndex].stream;
        courseType.value=courses[this.courseIndex].type;
        courseStartDate.value=courses[this.courseIndex].startDate;
        courseEndDate.value=courses[this.courseIndex].endDate;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.courseIndex=this.courseIndex;
    }

    function update(event){
        event.preventDefault();
        courses[this.courseIndex]=new Course(courseTitle.value, courseStream.value, courseType.value, courseStartDate.value, courseEndDate.value);
        divCourses.innerHTML="";
        for(let i=0; i< courses.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.courseIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(courses[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(course,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=courseToString(course);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;'
        paragraph.append(spanSpace,editButton);
        divCourses.append(paragraph);
    }
function TrainerPerCourse(trainer, course){
    this.trainer = trainer;
    this.course = course;
}

function trainerPCToString(trainerPerCourse){
    return (`Trainer: ${trainerPerCourse.trainer} 
             Course:  ${trainerPerCourse.course}`)
}

let trainersCourses=[];
    let trainerFullName=document.querySelector("firstName");
    let courseName=document.querySelector("lastName");

    let btnSubmit=document.getElementById('submit');
    btnSubmit.addEventListener("click",submit);

    let btnReset=document.getElementById('reset');
    btnReset.addEventListener('click', reset);

    let btnUpdate=document.getElementById('update');
    btnUpdate.addEventListener('click',update);

    let divTrainersPerC=document.getElementById("trainersPerC");

    function submit(event){
        event.preventDefault();
        let mytrainersCourses=new TrainerPerCourse(trainerFullName.value, courseName.value);
        trainersCourses.push(mytrainersCourses);
        let btnEdit=document.createElement('button');
        btnEdit.textContent='Edit';
        btnEdit.trainerPerCourseIndex=trainersCourses.length-1;
        btnEdit.addEventListener('click', edit);
        createParagraphElement(mytrainersCourses,btnEdit);
        btnReset.click();

    }

    function reset(event){
        btnSubmit.textContent="Add";
    }

    function edit(event){
        trainerFullName.value=trainersCourses[this.trainerPerCourseIndex].trainer;
        courseName.value=trainersCourses[this.trainerPerCourseIndex].course;
        btnSubmit.hidden=true;
        btnUpdate.hidden=false;
        btnUpdate.trainerPerCourseIndex=this.trainerPerCourseIndex;
    }

    function update(event){
        event.preventDefault();
        trainersCourses[this.trainerPerCourseIndex]=new TrainerPerCourse(trainerFullName.value, courseName.value);
        divTrainersPerC.innerHTML="";
        for(let i=0; i< trainersCourses.length; i++){
            let btnEdit=document.createElement('button');
            btnEdit.textContent='Edit';
            btnEdit.trainerPerCourseIndex=i;
            btnEdit.addEventListener('click', edit);
            createParagraphElement(trainersCourses[i], btnEdit)
        }
        btnUpdate.hidden=true;
        btnSubmit.hidden=false;
        btnReset.click();
    }

    function createParagraphElement(trainerPerCourse,editButton){
        let paragraph=document.createElement('p');
        paragraph.innerText=trainerPCToString(trainerPerCourse);
        let spanSpace=document.createElement('span');
        spanSpace.innerHTML='&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;'
        paragraph.append(spanSpace,editButton);
        divTrainersPerC.append(paragraph);
    }

    function handleSubmit(){
        const firstname = document.getElementById('firstName').value;
        const lastname = document.getElementById('lastName').value;
        const subject = document.querySelector('#subject').value;
    
        localStorage.setItem("FIRST", firstname);
        localStorage.setItem("LAST", lastname);
        localStorage.setItem("SUB", subject);
    
        return;
    }
    

